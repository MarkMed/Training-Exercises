function alertar(){
	alert('hola que haces?');
}