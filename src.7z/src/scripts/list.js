//constructor
var Human =  function(){}

var humanInstance = new Human(); 

var instanceObject = {

}
